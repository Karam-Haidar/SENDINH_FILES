import os
import pickle
import numpy as np
from deepface import DeepFace

# Directory where faces are stored
FACE_DB_PATH = "faces_db"

# Lists to store encodings and names
known_face_encodings = []
known_face_names = []

# Loop through each person’s folder
for person_name in os.listdir(FACE_DB_PATH):
    person_path = os.path.join(FACE_DB_PATH, person_name)
    if os.path.isdir(person_path):
        print(f"Processing images for {person_name}...")

        for image_name in os.listdir(person_path):
            image_path = os.path.join(person_path, image_name)

            try:
                # Extract deep learning-based embedding
                embedding = DeepFace.represent(img_path=image_path, model_name="Facenet")
                if embedding:
                    known_face_encodings.append(np.array(embedding[0]["embedding"]))
                    known_face_names.append(person_name)
            except:
                print(f"Skipping {image_path} (face not detected)")

# Save the trained model
data = {"encodings": known_face_encodings, "names": known_face_names}
with open("trained_faces.pkl", "wb") as f:
    pickle.dump(data, f)

print("Training complete! Model saved as trained_faces.pkl")
